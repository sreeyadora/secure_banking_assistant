# Secure Banking Bot

## Setup Instructions

1. Install dependencies:
```bash
pip install Flask
```

2. Run the app:
```bash
python app/main.py
```

3. Example Request (POST /api/interact):
```json
{
  "intent": "loan",
  "context": {
    "name": "Siya",
    "amount": "500000"
  }
}
```

## Security

- HMAC-based message signing for authenticity and integrity
- Timestamp to protect against replay attacks