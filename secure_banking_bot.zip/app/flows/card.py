def handle_card_block(context):
    card_type = context.get("card_type")
    last4 = context.get("last4")
    if not card_type or not last4:
        return {"response": "Please specify whether it’s a debit or credit card and the last 4 digits."}
    return {
        "response": f"Your {card_type} card ending in {last4} has been blocked. A replacement will be issued soon."
    }