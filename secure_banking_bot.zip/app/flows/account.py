def handle_account_query(context):
    query_type = context.get("type")
    if query_type == "balance":
        return {"response": "Your current balance is ₹25,000."}
    elif query_type == "statement":
        return {"response": "Here's your last 5 transactions: ..."}
    else:
        return {"response": "What information about your account would you like to retrieve?"}