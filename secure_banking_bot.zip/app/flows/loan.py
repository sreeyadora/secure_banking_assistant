def handle_loan_application(context):
    name = context.get("name")
    amount = context.get("amount")
    if not name or not amount:
        return {"response": "Please provide your name and the loan amount."}
    return {
        "response": f"Loan application submitted for {name} requesting ₹{amount}. We will get back to you shortly."
    }