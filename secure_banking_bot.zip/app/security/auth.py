import time
import hmac
import hashlib

SECRET_KEY = "supersecurekey"

def verify_request(request):
    timestamp = request.headers.get("X-Timestamp")
    signature = request.headers.get("X-Signature")
    body = request.data

    if not timestamp or not signature:
        return False

    try:
        timestamp = int(timestamp)
        if abs(time.time() - timestamp) > 300:
            return False  # Too old
    except ValueError:
        return False

    expected_sig = hmac.new(
        SECRET_KEY.encode(), f"{timestamp}.{body.decode()}".encode(), hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(expected_sig, signature)