from flask import Blueprint, request, jsonify
from app.flows.loan import handle_loan_application
from app.flows.card import handle_card_block
from app.flows.account import handle_account_query
from app.security.auth import verify_request

api_blueprint = Blueprint("api", __name__)

@api_blueprint.route("/interact", methods=["POST"])
def interact():
    if not verify_request(request):
        return jsonify({"error": "Unauthorized or tampered request"}), 403

    data = request.json
    intent = data.get("intent")
    context = data.get("context", {})

    if intent == "loan":
        return jsonify(handle_loan_application(context))
    elif intent == "block_card":
        return jsonify(handle_card_block(context))
    elif intent == "account_query":
        return jsonify(handle_account_query(context))
    else:
        return jsonify({"response": "I'm not sure what you're asking. Could you clarify?"})